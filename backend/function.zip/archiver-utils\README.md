# Archiver Utils

## Things of Interest
- [Changelog](https://github.com/archiverjs/archiver-utils/releases)
- [Contributing](https://github.com/archiverjs/archiver-utils/blob/master/CONTRIBUTING.md)
- [MIT License](https://github.com/archiverjs/archiver-utils/blob/master/LICENSE)
