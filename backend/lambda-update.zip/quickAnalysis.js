// backend/lambda/quickAnalysis.js - COMPLETE FIXED VERSION
const AWS = require("aws-sdk");
const bedrock = new AWS.BedrockRuntime({ region: "us-east-1" });

exports.handler = async (event) => {
  console.log("=== LAMBDA STARTED ===");

  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "OPTIONS,POST",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "CORS OK" }),
    };
  }

  try {
    let body = JSON.parse(event.body);
    const { imageBase64, images, equipmentType } = body;

    // Support both single image (imageBase64) and multiple images (images array)
    const imagesToAnalyze = images && images.length > 0 ? images : [imageBase64];

    console.log("=== IMAGE ANALYSIS REQUEST ===");
    console.log(`Equipment type: ${equipmentType || 'HVAC (default)'}`);
    console.log(`Number of images received: ${imagesToAnalyze.length}`);
    if (imagesToAnalyze.length > 1) {
      console.log(`  Image 1: Nameplate (manufacturer, model, serial, electrical specs)`);
      console.log(`  Image 2+: Fuse label or additional views`);
    }

    // COMPREHENSIVE PROMPT WITH JSON-ONLY ENFORCEMENT AND SERIAL NUMBER DECODING
    const comprehensivePrompt = `You are an expert MEP engineer analyzing HVAC equipment images. You may receive MULTIPLE IMAGES:
1. RTU NAMEPLATE IMAGE - Contains manufacturer, model, serial, electrical specs
2. FUSE LABEL IMAGE (optional) - Shows fuse size from inside the disconnect box

Extract ALL visible information and return it in the exact JSON format below.

CRITICAL: Your response must be ONLY valid JSON with no additional text before or after. Do not include explanations, markdown code blocks, or any other text. Start your response with { and end with }.

CRITICAL INSTRUCTIONS:
1. Extract EVERY field you can see across ALL provided images
2. For fields that are worn/damaged/illegible: use "Not legible"
3. For fields that are completely missing from ALL images: use "Not Available"
4. NEVER leave any field as null - always use either the actual value, "Not legible", or "Not Available"
5. **MULTI-IMAGE HANDLING**:
   - Examine ALL images provided
   - RTU nameplate image: Use for manufacturer, model, serial, electrical specs, compressor info, fan motors
   - Fuse label image: Look for fuse size label (e.g., "60A", "30 AMP FUSE", "15 AMP") - extract ONLY the fuse size from this image
   - If fuse label image shows fuse size, use that value for "electrical.fuseSize"
   - If no fuse label image provided, try to get fuse size from nameplate or use "Not Available"
6. **OCR ACCURACY - ABSOLUTELY CRITICAL - READ THIS CAREFULLY**:

   ⚠️ **CRITICAL RULE**: If ANY character is unclear or ambiguous, mark the ENTIRE field as "Not legible" - DO NOT GUESS!

   **MOST CRITICAL CHARACTER CONFUSIONS TO AVOID**:

   ❌ **"0" (ZERO) vs "D" (LETTER D)** - THIS IS THE #1 ERROR:
      - ZERO (0): Completely round or oval shape, NO straight vertical line, often narrower
      - LETTER D: Has a STRAIGHT VERTICAL LINE on the left side
      - Example: "48FCEA06A2A3A0A0A0A0" - the characters after A2A3 are ALL ZEROS (0), NOT the letter D
      - If you see what looks like "0DA0", it's almost certainly "0A0A0" with zeros, NOT a D
      - In model numbers with repeating patterns like "A0A0A0", DO NOT insert a D where zeros appear

   ❌ **"0" (ZERO) vs "O" (LETTER O)**:
      - ZERO: Narrower, often has a slash through it
      - LETTER O: Wider, perfectly round
      - In alphanumeric codes, context matters: "A0" (letter-zero) vs "AO" (letter-letter)

   ❌ **"1" vs "4" vs "7"**:
      - 1: Straight vertical line, small base
      - 4: Open top, horizontal line crosses vertical
      - 7: Horizontal top bar

   ❌ **"2" vs "Z"**:
      - 2: Curved top, number context
      - Z: Angular, letter context

   ❌ **"8" vs "6"**:
      - 8: Symmetrical top and bottom
      - 6: Only has tail at bottom

   ❌ **"5" vs "S"**:
      - 5: Angular corners
      - S: Curved throughout

   **CHARACTER-BY-CHARACTER VERIFICATION REQUIRED FOR**:
   - ✅ Model numbers: Read EACH character individually, verify it against the patterns above
   - ✅ Serial numbers: Verify each digit, watch for 0 vs O vs D
   - ✅ RLA (Rated Load Amps): Verify decimal point position (e.g., "24.4" NOT "14.4")
   - ✅ LRA (Locked Rotor Amps): Verify each digit (e.g., "144" NOT "86.0")
   - ✅ FLA (Full Load Amps): For compressor and fan motors
   - ✅ Voltage ratings: Ensure correct numbers

   **EXAMPLE - MODEL NUMBER "48FCEA06A2A3A0A0A0"** (17 characters):
   - This has a REPEATING PATTERN at the end: A0A0A0 (letter A, zero, letter A, zero, etc.)
   - DO NOT read this as "48FCEA06A2A3A0DA0A0" (adds D where zero should be)
   - DO NOT read this as "48FCEA06A2A3A0A0A0A0" (adds extra A0 at end, making it 19 characters)
   - The correct reading is EXACTLY 17 characters: "48FCEA06A2A3A0A0A0"
   - After "A2A3", the pattern is: A0A0A0 (three repetitions of A0)
   - Verify: Is each character round/oval (0) or does it have a straight left edge (D)?
   - Stop at the natural boundary - don't continue into adjacent text

   **MODEL NUMBER LENGTH VALIDATION - CRITICAL**:
   - ⚠️ **CARRIER / BRYANT / PAYNE**: Model numbers are typically **17-18 characters maximum**
   - ⚠️ **If you extract more than 18 characters, you've read TOO FAR into adjacent text**
   - STOP at the natural end of the model number text block
   - Look for visual boundaries: spacing, borders, next label field
   - Example: "48FCEA06A2A3A0A0A0" is 17 characters - DO NOT add "A0" at the end to make it 19
   - If the model appears to be 19-20+ characters, verify you haven't included:
     * Adjacent serial number digits
     * Suffix codes from next field
     * Rating codes that are separate
   - Common manufacturers' model length limits:
     * Carrier/Bryant/Payne: 17-18 characters
     * Lennox: 10-15 characters
     * Trane: 10-14 characters
     * York: 12-16 characters

   **IF IN DOUBT**:
   - Mark the entire field as "Not legible"
   - DO NOT guess between similar characters
   - Better to mark "Not legible" than to provide incorrect data
   - The user can manually verify unclear characters
7. **SERIAL NUMBER DECODING - CRITICAL**: Decode the serial number to determine manufacturing year and calculate current age. Each manufacturer has a different format:

   **CARRIER / BRYANT / PAYNE:**
   - Format: 4 digits + letters/numbers (e.g., 5210XXXXXX)
   - First 2 digits = year (52 = 2002, 03 = 2003, 13 = 2013, 21 = 2021)
   - 3rd & 4th digits = week of manufacture
   - If year < 24, add 2000 (e.g., 03 = 2003, 21 = 2021)
   - If year >= 24, could be 1924 (very old) or 2024+ (recent)
   - Examples: "5210" = week 10 of 2002, "1352" = week 52 of 2013

   **LENNOX:**
   - Format: YYWWXXXXXX (10 digits, e.g., 5608D05236)
   - First 2 digits YY = year (56 = 2006, 08 = 2008, 15 = 2015)
   - Next 2 digits WW = week (01-52)
   - If YY < 24, year = 2000 + YY (e.g., 06 = 2006, 15 = 2015)
   - If YY >= 24, year = 1900 + YY (e.g., 56 = 1956) UNLESS recent unit
   - For modern units: 56-99 likely means 1956-1999, 00-24 means 2000-2024
   - Examples: "5608" = week 8 of 2006, "1552" = week 52 of 2015

   **TRANE / AMERICAN STANDARD:**
   - Format varies by age
   - Older units (pre-2002): Serial starts with letter, then numbers
   - Newer units (2002+): 9-10 digit format
   - Post-2010: Often starts with year code (e.g., 3 = 2013, 4 = 2014, 5 = 2015, 6 = 2016)
   - Example: "5082M12345" likely 2015, week 82 is invalid so week 08 year 2015

   **YORK / COLEMAN / LUXAIRE:**
   - Format: ABCDEFGHIJ (letter-based encoding)
   - Year code: A=2004, B=2005, C=2006, D=2007, E=2008, F=2009, G=2010, H=2011, J=2012, K=2013, L=2014, M=2015, N=2016, P=2017, R=2018, S=2019, T=2020, U=2021, V=2022, W=2023, X=2024
   - Example: "MCAH123456" = M=2015

   **GOODMAN / AMANA:**
   - Format: 10 digits (YYMMDXXXXX)
   - First 2 digits YY = year (same rules: < 24 = 2000+, >= 50 = 1900+)
   - Next 2 digits MM = month (01-12)
   - Next 1 digit D = decade code (sometimes)
   - Examples: "1305123456" = May 2013, "2101234567" = January 2021

   **RHEEM / RUUD:**
   - Format varies
   - Often month-year codes in middle of serial
   - Letters can indicate year (A=2002, B=2003, etc.)
   - Example: "M051234567" where M=month code, 05=year 2005

   **GENERAL DECODING RULES:**
   - If serial format doesn't match known patterns: use "Not legible" for year and age
   - Current year for age calculation: 2025
   - Age = 2025 - manufacturing year
   - If you identify year as 2006, age = 19 years
   - If you identify year as 2015, age = 10 years

8. **CARRIER RTU NAMEPLATE TABLE STRUCTURE - ABSOLUTELY CRITICAL**:

   ⚠️ **CARRIER NAMEPLATES HAVE A SPECIFIC TABLE LAYOUT - DO NOT MIX DATA FROM DIFFERENT ROWS**

   **TOP SECTION - BASIC INFO:**
   - **MODEL**: Top right corner (e.g., "50FC-A06A2A5A0A0A0")
     * Maximum 17-18 characters - STOP when model ends
     * Pattern: ##XXXX##X#X#X#X# (digits and letters alternating)
     * Common ending patterns: "...A0A0A0" NOT "...A0A0A0A0A0"
     * If you read more than 18 characters, you've READ TOO FAR

   - **SERIAL**: Below model (e.g., "0621C68356")
     * CRITICAL 8 vs 6 distinction:
       - "8" has TWO loops (top circle + bottom circle, figure-eight shape)
       - "6" has ONE loop (bottom circle only, with tail at top)
     * If uncertain about ANY digit, mark as "?" instead of guessing
     * Common confusion: "68" vs "66" - verify each digit individually

   **MAIN TABLE STRUCTURE (read row by row from top to bottom):**

   **ROW 1: COMP A** (Compressor A)
   - Columns: QTY | VOLTS AC | PH | HZ | RLA | LRA | REF SYSTEM
   - Example: "1 | 208/230 | 3 | 60 | 16.0 | 110 | R-410A"
   - PH value here is for THIS COMPRESSOR ONLY (not unit phase)
   - Extract: RLA, LRA values from this row

   **ROW 2: COMP B** (Compressor B - if dual compressor unit)
   - Same column structure as COMP A
   - May be empty if single compressor unit

   **ROW 3: FAN MTR OUTDOOR** (Outdoor Fan Motor)
   - Columns: QTY | VOLTS AC | PH | HZ | FLA
   - Example: "1 | 208/230 | 1 | 60 | 1.5"
   - PH value here is for THIS MOTOR ONLY (often 1-phase even if unit is 3-phase)
   - ⚠️ DO NOT use this PH value for unit phase
   - Extract: FLA value from this row

   **ROW 4: FAN MTR INDOOR** (Indoor Blower Motor)
   - Columns: QTY | VOLTS AC | PH | HZ | FLA
   - Example: "1 | 208/230 | 1 | 60 | 8.6"
   - PH value here is for THIS MOTOR ONLY
   - ⚠️ DO NOT use this PH value for unit phase
   - Extract: FLA value from this row

   **ROWS 5-8**: ELEC HEAT, OTHER, ENV SUPPLY, ENV EXHAUST, ENV WHEEL
   - Often empty or unit-specific configurations
   - Skip unless data is visible

   **ROW 9: POWER SUPPLY** ⭐⭐⭐ **THIS IS THE MOST IMPORTANT ROW** ⭐⭐⭐
   - Format: "208/230  VOLTS  3 PH  60 HZ"
   - Columns: VOLTAGE | VOLTS | PHASE | PH | FREQUENCY | HZ
   - Example: "208/230 VOLTS 3 PH 60 HZ"

   - ⚠️ **CRITICAL - THIS ROW CONTAINS THE UNIT'S ELECTRICAL SPECIFICATIONS:**
     * **Voltage**: 208/230 - THIS IS THE UNIT VOLTAGE (use this for electrical.voltage)
     * **Phase**: 3 - THIS IS THE UNIT PHASE (use this for electrical.phase)
     * **Frequency**: 60 Hz - THIS IS THE UNIT FREQUENCY

   - ⚠️ **DO NOT confuse unit phase with component phase:**
     * Fan motors may be 1-phase (from FAN MTR rows)
     * BUT the unit itself may be 3-phase (from POWER SUPPLY row)
     * ALWAYS use the POWER SUPPLY row for electrical.phase

   **BELOW POWER SUPPLY ROW:**
   - "PERMISSIBLE VOLTAGE AT UNIT: 253 MAX 187 MIN"
   - "MIN CKT AMPS:" (Minimum Circuit Ampacity - use this for MCA)
   - "MAX FUSE OR HACR BREAKER PER NEC:" (Maximum fuse size)
   - "MAX OVERCURRENT PROTECTION DEVICE:" values

   **BOTTOM SECTION:**
   - "COOLING CAPACITY Btu/Hr:" (e.g., 58500)
   - "CAPACITY KW:" (e.g., 17.1)
   - SEER / COP / EER ratings

   **EXTRACTION MAPPING - USE THESE SPECIFIC VALUES:**
   - electrical.voltage → POWER SUPPLY row voltage (e.g., "208/230")
   - electrical.phase → POWER SUPPLY row phase (e.g., "3")
   - compressor1.rla → COMP A row RLA value
   - compressor1.lra → COMP A row LRA value
   - outdoorFanMotor.fla → FAN MTR OUTDOOR row FLA value
   - indoorFanMotor.fla → FAN MTR INDOOR row FLA value
   - electrical.mca → "MIN CKT AMPS" value below POWER SUPPLY row
   - electrical.mocp → "MAX FUSE OR HACR BREAKER PER NEC" value

   **COMMON MISTAKES TO AVOID:**
   - ❌ Using fan motor phase (1) instead of POWER SUPPLY phase (3)
   - ❌ Reading model number too far and adding extra characters
   - ❌ Confusing "68" with "66" in serial numbers (8 has two loops, 6 has one loop)
   - ❌ Mixing data from different table rows
   - ❌ Reading compressor phase as unit phase

9. For electrical specs, look for MCA, MOCP, RLA, LRA labels across all images
10. Return confidence level for each major section
11. **COOLING TONNAGE - CRITICAL**: This is the COOLING CAPACITY, NOT the unit weight:
   - Look for labels: "COOLING CAPACITY", "TONS", "TON", "BTU/H", "MBH"
   - Common conversions:
     * 60,000 BTU/hr = 5 tons
     * 120,000 BTU/hr (or 120 MBH) = 10 tons
     * 180,000 BTU/hr (or 180 MBH) = 15 tons
   - Model number clues:
     * ZCA060xxx = 5 tons (060 = 60,000 BTU/hr)
     * LGA180xxx = 15 tons (180 = 180,000 BTU/hr)
     * LCA120xxx = 10 tons (120 = 120,000 BTU/hr)
   - NEVER report shipping weight (e.g., "5 LBS 6 OZ") as tonnage
   - NEVER report refrigerant charge weight as tonnage
   - Format output as: "5 tons", "10 tons", "15 tons", or "Not legible" or "Not Available"

RETURN THIS EXACT JSON STRUCTURE (NO OTHER TEXT):
{
  "systemType": {
    "category": "Packaged Roof Top Unit" or "Split System" or "Other" or "Not Available",
    "configuration": "Electric Cooling / Gas Heat" or "Electric Cooling / Electric Heat" or "Electric Cooling / Heat Pump" or "Electric Cooling / No Heat" or "Not Available",
    "confidence": "high" or "medium" or "low"
  },
  "basicInfo": {
    "manufacturer": "string or 'Not legible' or 'Not Available'",
    "model": "string or 'Not legible' or 'Not Available'",
    "serialNumber": "string or 'Not legible' or 'Not Available'",
    "manufacturingYear": "string or 'Not legible' or 'Not Available'",
    "currentAge": "string or 'Not Available'",
    "condition": "based on nameplate condition - Good/Fair/Poor or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "electrical": {
    "disconnectSize": "string or 'Not legible' or 'Not Available'",
    "fuseSize": "string or 'Not legible' or 'Not Available'",
    "voltage": "string or 'Not legible' or 'Not Available'",
    "phase": "1" or "3" or "Not legible" or "Not Available",
    "kw": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "compressor1": {
    "quantity": "string or 'Not legible' or 'Not Available'",
    "volts": "string or 'Not legible' or 'Not Available'",
    "phase": "1" or "3" or "Not legible" or "Not Available",
    "rla": "string or 'Not legible' or 'Not Available'",
    "lra": "string or 'Not legible' or 'Not Available'",
    "mca": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "compressor2": {
    "quantity": "string or 'Not legible' or 'Not Available'",
    "volts": "string or 'Not legible' or 'Not Available'",
    "phase": "1" or "3" or "Not legible" or "Not Available",
    "rla": "string or 'Not legible' or 'Not Available'",
    "lra": "string or 'Not legible' or 'Not Available'",
    "mocp": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "condenserFanMotor": {
    "quantity": "string or 'Not legible' or 'Not Available'",
    "volts": "string or 'Not legible' or 'Not Available'",
    "phase": "1" or "3" or "Not legible" or "Not Available",
    "fla": "string or 'Not legible' or 'Not Available'",
    "hp": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "indoorFanMotor": {
    "quantity": "string or 'Not legible' or 'Not Available'",
    "volts": "string or 'Not legible' or 'Not Available'",
    "phase": "1" or "3" or "Not legible" or "Not Available",
    "fla": "string or 'Not legible' or 'Not Available'",
    "hp": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "gasInformation": {
    "gasType": "Natural Gas" or "Propane" or "Not legible" or "Not Available",
    "inputMinBTU": "string or 'Not legible' or 'Not Available'",
    "inputMaxBTU": "string or 'Not legible' or 'Not Available'",
    "outputCapacityBTU": "string or 'Not legible' or 'Not Available'",
    "gasPipeSize": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "cooling": {
    "tonnage": "string - COOLING CAPACITY ONLY (e.g. '5 tons', '10 tons', '15 tons') or 'Not legible' or 'Not Available'. Calculate from BTU/hr or model number. NEVER use unit weight.",
    "refrigerant": "string or 'Not legible' or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "serviceLife": {
    "assessment": "Within service life (0-15 years)" or "BEYOND SERVICE LIFE (15+ years)" or "Unable to determine",
    "recommendation": "Reuse" or "Replace" or "Further evaluation needed",
    "ashrae_standard": "ASHRAE median service life for RTU: 15 years"
  },
  "warnings": [
    "list any safety concerns, illegible fields, or critical issues - if the nameplate is worn or damaged, include specific fields that are illegible"
  ],
  "overallConfidence": "high" or "medium" or "low"
}

EXAMPLE FOR LENNOX LCA120H2RN1Y, Serial 5608D05236:
- Manufacturer: Lennox
- Serial 5608 = Year 2006 (56 = 06, 08 = week 8)
- manufacturingYear: "2006"
- currentAge: "19"
- Age = 2025 - 2006 = 19 years
- Model LCA120 = 10 tons (120 MBH / 12 = 10 tons)
- Status: BEYOND SERVICE LIFE

EXAMPLE FOR CARRIER, Serial 5210ABCDEF:
- Manufacturer: Carrier
- Serial 5210 = Year 2002 (52 = 02), week 10
- manufacturingYear: "2002"
- currentAge: "23"
- Age = 2025 - 2002 = 23 years
- Status: BEYOND SERVICE LIFE

EXAMPLE FOR YORK, Serial MCAH123456:
- Manufacturer: York
- Serial MCAH = M = 2015
- manufacturingYear: "2015"
- currentAge: "10"
- Age = 2025 - 2015 = 10 years
- Status: Within service life

EXAMPLE FOR GOODMAN, Serial 1305123456:
- Manufacturer: Goodman
- Serial 1305 = Year 2013 (13), month 05 (May)
- manufacturingYear: "2013"
- currentAge: "12"
- Age = 2025 - 2013 = 12 years
- Status: Within service life

Extract all visible information now. Apply the serial number decoding rules based on the manufacturer you identify. RETURN ONLY JSON, NO OTHER TEXT.`;

    // ELECTRICAL PANEL PROMPT - REALISTIC NAMEPLATE EXTRACTION ONLY
    const electricalPanelPrompt = `You are an expert electrical engineer analyzing an electrical panel nameplate. Extract ONLY what is clearly visible on the nameplate - be realistic about what can be read from a photo.

CRITICAL: Your response must be ONLY valid JSON with no additional text before or after. Do not include explanations, markdown code blocks, or any other text. Start your response with { and end with }.

CRITICAL INSTRUCTIONS:
1. Extract ONLY information visible on the nameplate - most panels show limited information
2. For fields not visible on nameplate: use "Not Available"
3. For fields that are worn/damaged/illegible: use "Not legible"
4. NEVER leave any field as null - always use either the actual value, "Not legible", or "Not Available"
5. Be realistic - most panel nameplates only show: manufacturer, model, voltage, bus rating, and sometimes main breaker size
6. Physical dimensions (width, depth, height) typically require field measurement - use "Not Available" unless clearly labeled
7. Pole spaces require counting and are often not visible - use "Not Available" unless clearly visible
8. Advanced ratings (fault current, series rating, AIC) are rarely on nameplates - use "Not Available" unless clearly visible

SAFETY WARNINGS - CRITICAL:
- Federal Pacific Electric (FPE): Known fire hazard, IMMEDIATE REPLACEMENT REQUIRED
- Zinsco / GTE-Sylvania: Known fire hazard, IMMEDIATE REPLACEMENT REQUIRED
- Challenger: Fire safety concerns, recommend replacement
- Set appropriate warning flags if these manufacturers are detected

VOLTAGE CONFIGURATION IDENTIFICATION:
Common formats you may see:
- "208Y/120V 3Ø 4W" = 208Y/120V 3-phase 4-wire
- "480Y/277V 3Ø 4W" = 480Y/277V 3-phase 4-wire
- "120/240V 1Ø 3W" = 120/240V 1-phase 3-wire
- "240Δ/120V 3Ø 4W" = 240D/120V 3-phase 4-wire

REALISTICALLY EXTRACTABLE FROM NAMEPLATE PHOTO:
✓ Manufacturer name
✓ Model number
✓ Serial number (sometimes)
✓ Voltage configuration (e.g., 120/208V)
✓ Phase (1-phase or 3-phase)
✓ Bus rating (e.g., 400A)
✓ Main breaker size if visible
✗ Physical dimensions (need measurement)
✗ Exact pole space count (need counting, often illegible)
✗ Fault current ratings (rarely on nameplate)
✗ Panel schedule details (too small to read)
✗ Individual circuit information

RETURN THIS EXACT JSON STRUCTURE (NO OTHER TEXT):
{
  "systemType": {
    "category": "Electrical Distribution Panel",
    "panelType": "Load Center" or "Panelboard" or "Main Distribution Panel" or "Switchboard" or "Not Available",
    "confidence": "high" or "medium" or "low"
  },
  "basicInfo": {
    "manufacturer": "string or 'Not legible' or 'Not Available'",
    "model": "string or 'Not legible' or 'Not Available'",
    "serialNumber": "string or 'Not legible' or 'Not Available'",
    "poleSpaces": "number as string or 'Not Available' - only if clearly visible",
    "condition": "based on panel condition - Good/Fair/Poor/Hazardous or 'Not Available'",
    "confidence": "high" or "medium" or "low"
  },
  "electrical": {
    "voltage": "string (e.g., '120/208V', '480Y/277V') or 'Not legible' or 'Not Available'",
    "phase": "1-phase" or "3-phase" or "Not legible" or "Not Available'",
    "wireConfig": "4-wire" or "3-wire" or "Not legible" or "Not Available'",
    "busRating": "string with A (e.g., '400A', '225A') or 'Not legible' or 'Not Available'",
    "availableFaultCurrent": "string or 'Not Available' - rarely visible on nameplate",
    "seriesRatedCombination": "string or 'Not Available' - rarely visible",
    "lowestBreakerAIC": "string or 'Not Available' - rarely visible",
    "confidence": "high" or "medium" or "low"
  },
  "incomingTermination": {
    "type": "Breaker Main" or "Main Lug Only" or "Not Available",
    "mainBreakerSize": "string with A (e.g., '400A') or 'Not Available' - only if main breaker visible",
    "mainBreakerPoles": "1" or "2" or "3" or "Not Available",
    "confidence": "high" or "medium" or "low"
  },
  "mounting": {
    "type": "Surface" or "Flush" or "Semi-Flush" or "Within Switchboard" or "Not Available",
    "confidence": "low" - usually cannot determine from nameplate alone
  },
  "physicalDimensions": {
    "width": "Not Available - requires field measurement",
    "depth": "Not Available - requires field measurement",
    "height": "Not Available - requires field measurement",
    "note": "Physical dimensions typically require field measurement and are not on nameplates"
  },
  "safetyWarnings": {
    "isFPE": true or false,
    "isZinsco": true or false,
    "isChallenger": true or false,
    "warnings": [
      "array of safety warnings - include IMMEDIATE REPLACEMENT REQUIRED for FPE/Zinsco"
    ]
  },
  "confidenceScores": {
    "manufacturer": 0.0-1.0,
    "model": 0.0-1.0,
    "voltage": 0.0-1.0,
    "busRating": 0.0-1.0,
    "mainBreakerSize": 0.0-1.0,
    "overall": 0.0-1.0
  },
  "extractionQuality": {
    "nameplateReadability": "EXCELLENT" | "GOOD" | "FAIR" | "POOR",
    "glarePresent": true | false,
    "focusIssues": true | false,
    "partialOcclusion": true | false,
    "weatheringDamage": true | false
  },
  "missingFields": [
    "List fields that are Not Available or Not legible"
  ],
  "recommendedFollowup": [
    "Suggest actions if critical data is missing",
    "Examples: 'Retake photo without glare', 'Photo of panel interior needed for pole count', 'Field verify bus rating'"
  ],
  "warnings": [
    "list any illegible fields, critical issues, or safety concerns"
  ],
  "overallConfidence": "high" or "medium" or "low"
}

EXAMPLE OUTPUT FOR SQUARE D PANEL:
{
  "systemType": {
    "category": "Electrical Distribution Panel",
    "panelType": "Load Center",
    "confidence": "high"
  },
  "basicInfo": {
    "manufacturer": "Square D",
    "model": "NQOD442L225G",
    "serialNumber": "Not legible",
    "poleSpaces": "42",
    "condition": "Good",
    "confidence": "high"
  },
  "electrical": {
    "voltage": "120/208V",
    "phase": "3-phase",
    "wireConfig": "4-wire",
    "busRating": "400A",
    "availableFaultCurrent": "Not Available",
    "seriesRatedCombination": "Not Available",
    "lowestBreakerAIC": "Not Available",
    "confidence": "high"
  },
  "incomingTermination": {
    "type": "Breaker Main",
    "mainBreakerSize": "400A",
    "mainBreakerPoles": "3",
    "confidence": "high"
  },
  "mounting": {
    "type": "Surface",
    "confidence": "low"
  },
  "physicalDimensions": {
    "width": "Not Available - requires field measurement",
    "depth": "Not Available - requires field measurement",
    "height": "Not Available - requires field measurement",
    "note": "Physical dimensions typically require field measurement and are not on nameplates"
  },
  "safetyWarnings": {
    "isFPE": false,
    "isZinsco": false,
    "isChallenger": false,
    "warnings": []
  },
  "confidenceScores": {
    "manufacturer": 1.0,
    "model": 1.0,
    "voltage": 0.95,
    "busRating": 0.95,
    "mainBreakerSize": 0.9,
    "overall": 0.95
  },
  "extractionQuality": {
    "nameplateReadability": "EXCELLENT",
    "glarePresent": false,
    "focusIssues": false,
    "partialOcclusion": false,
    "weatheringDamage": false
  },
  "missingFields": [
    "serialNumber - worn/illegible",
    "availableFaultCurrent - not on nameplate",
    "seriesRatedCombination - not on nameplate"
  ],
  "recommendedFollowup": [],
  "warnings": [
    "Serial number not legible due to wear",
    "Advanced electrical ratings not visible on nameplate"
  ],
  "overallConfidence": "high"
}

EXAMPLE OUTPUT FOR FPE PANEL (HAZARDOUS):
{
  "systemType": {
    "category": "Electrical Distribution Panel",
    "panelType": "Load Center",
    "confidence": "high"
  },
  "basicInfo": {
    "manufacturer": "Federal Pacific Electric",
    "model": "Not legible",
    "serialNumber": "Not legible",
    "poleSpaces": "Not Available",
    "condition": "Hazardous",
    "confidence": "high"
  },
  "electrical": {
    "voltage": "120/240V",
    "phase": "1-phase",
    "wireConfig": "3-wire",
    "busRating": "200A",
    "availableFaultCurrent": "Not Available",
    "seriesRatedCombination": "Not Available",
    "lowestBreakerAIC": "Not Available",
    "confidence": "medium"
  },
  "incomingTermination": {
    "type": "Breaker Main",
    "mainBreakerSize": "200A",
    "mainBreakerPoles": "2",
    "confidence": "medium"
  },
  "mounting": {
    "type": "Not Available",
    "confidence": "low"
  },
  "physicalDimensions": {
    "width": "Not Available - requires field measurement",
    "depth": "Not Available - requires field measurement",
    "height": "Not Available - requires field measurement",
    "note": "Physical dimensions typically require field measurement and are not on nameplates"
  },
  "safetyWarnings": {
    "isFPE": true,
    "isZinsco": false,
    "isChallenger": false,
    "warnings": [
      "FEDERAL PACIFIC ELECTRIC PANEL DETECTED - IMMEDIATE REPLACEMENT REQUIRED",
      "FPE panels have documented fire hazards and breaker failures",
      "This panel poses a serious safety risk and should be replaced immediately"
    ]
  },
  "warnings": [
    "FEDERAL PACIFIC ELECTRIC PANEL - IMMEDIATE REPLACEMENT REQUIRED",
    "Model and serial numbers not legible",
    "This is a known fire hazard"
  ],
  "overallConfidence": "medium"
}

Extract all visible information from the electrical panel nameplate. Be realistic about what can be seen in a photo. RETURN ONLY JSON, NO OTHER TEXT.`;

    // TRANSFORMER PROMPT - REALISTIC NAMEPLATE EXTRACTION ONLY
    const transformerPrompt = `You are an expert electrical engineer analyzing a transformer nameplate. Extract ONLY what is clearly visible on the nameplate - be realistic about what can be read from a photo.

CRITICAL: Your response must be ONLY valid JSON with no additional text before or after. Do not include explanations, markdown code blocks, or any other text. Start your response with { and end with }.

CRITICAL INSTRUCTIONS:
1. Extract ONLY information visible on the nameplate - most transformers show kVA, voltages, and manufacturer
2. For fields not visible on nameplate: use "Not Available"
3. For fields that are worn/damaged/illegible: use "Not legible"
4. NEVER leave any field as null - always use either the actual value, "Not legible", or "Not Available"
5. Be realistic - most transformer nameplates show: manufacturer, model, kVA, primary voltage, secondary voltage, phase
6. Physical dimensions (width, depth, height, weight) typically require field measurement - use "Not Available" unless clearly labeled
7. Detailed ratings (impedance, insulation, temperature rise) are often small print - use "Not Available" unless clearly visible
8. Wiring details require field observation - always use "Not Available"

VOLTAGE CONFIGURATION IDENTIFICATION:
Common transformer voltage formats:
- "208Y/120V" = 208Y/120V (wye configuration)
- "480Y/277V" = 480Y/277V (wye configuration)
- "240D/120V" = 240D/120V (delta configuration)
- "480V" = 480V (primary voltage)
- "600D" = 600D (delta configuration)
- "120/240V" = 120/240V (single phase)

REALISTICALLY EXTRACTABLE FROM TRANSFORMER NAMEPLATE PHOTO:
✓ Manufacturer name
✓ Model number
✓ Serial number (sometimes)
✓ kVA rating (power rating)
✓ Primary voltage (e.g., 480V, 600V)
✓ Secondary voltage (e.g., 208Y/120V, 480Y/277V)
✓ Phase (single phase or three phase)
✓ Transformer type (Dry Type, Oil Filled, Pad Mounted)
✗ Physical dimensions (width, depth, height, weight - need measurement)
✗ Impedance rating (often small print)
✗ Insulation rating (often small print)
✗ Temperature rise (often small print)
✗ Wiring details (need field observation)
✗ Required clearances (need field measurement)

RETURN THIS EXACT JSON STRUCTURE (NO OTHER TEXT):
{
  "systemType": {
    "category": "Electrical Transformer",
    "transformerType": "Dry Type" or "Oil Filled" or "Pad Mounted" or "Cast Coil" or "Not Available",
    "confidence": "high" or "medium" or "low"
  },
  "basicInfo": {
    "manufacturer": "string or 'Not legible' or 'Not Available'",
    "model": "string or 'Not legible' or 'Not Available'",
    "serialNumber": "string or 'Not legible' or 'Not Available'",
    "phase": "Three Phase" or "Single Phase" or "Not legible" or "Not Available",
    "confidence": "high" or "medium" or "low"
  },
  "electrical": {
    "powerRating": "string with kVA (e.g., '75 kVA', '150 kVA') or 'Not legible' or 'Not Available'",
    "primaryVoltage": "string (e.g., '480V', '600V', '240V') or 'Not legible' or 'Not Available'",
    "secondaryVoltage": "string (e.g., '208Y/120V', '480Y/277V', '120/240V') or 'Not legible' or 'Not Available'",
    "impedance": "string with % (e.g., '3.5%') or 'Not Available' - often small print",
    "insulationRating": "string with °C (e.g., '150°C') or 'Not Available' - often small print",
    "temperatureRise": "string with °C (e.g., '80°C') or 'Not Available' - often small print",
    "confidence": "high" or "medium" or "low"
  },
  "mounting": {
    "type": "Floor" or "Suspended" or "Wall" or "Pad" or "Not Available",
    "confidence": "low" - usually cannot determine from nameplate alone
  },
  "physicalDimensions": {
    "width": "Not Available - requires field measurement",
    "depth": "Not Available - requires field measurement",
    "height": "Not Available - requires field measurement",
    "weight": "string with lbs or 'Not Available' - rarely visible",
    "note": "Physical dimensions typically require field measurement and are not always on nameplates"
  },
  "wiringDetails": {
    "note": "Wiring details require field observation and cannot be determined from nameplate photo",
    "primaries": "Not Available - requires field observation",
    "secondaries": "Not Available - requires field observation",
    "wireMaterial": "Not Available - requires field observation",
    "wireSize": "Not Available - requires field observation",
    "conduitSize": "Not Available - requires field observation"
  },
  "confidenceScores": {
    "manufacturer": 0.0-1.0,
    "model": 0.0-1.0,
    "powerRating": 0.0-1.0,
    "primaryVoltage": 0.0-1.0,
    "secondaryVoltage": 0.0-1.0,
    "overall": 0.0-1.0
  },
  "extractionQuality": {
    "nameplateReadability": "EXCELLENT" | "GOOD" | "FAIR" | "POOR",
    "glarePresent": true | false,
    "focusIssues": true | false,
    "partialOcclusion": true | false,
    "weatheringDamage": true | false
  },
  "missingFields": [
    "List fields that are Not Available or Not legible"
  ],
  "recommendedFollowup": [
    "Suggest actions if critical data is missing",
    "Examples: 'Retake photo without glare', 'Field verify impedance rating', 'Photo of secondary side nameplate needed'"
  ],
  "warnings": [
    "list any illegible fields or critical issues - no safety warnings needed for transformers unless obvious damage visible"
  ],
  "overallConfidence": "high" or "medium" or "low"
}

EXAMPLE OUTPUT FOR SQUARE D DRY TYPE TRANSFORMER:
{
  "systemType": {
    "category": "Electrical Transformer",
    "transformerType": "Dry Type",
    "confidence": "high"
  },
  "basicInfo": {
    "manufacturer": "Square D",
    "model": "EE75T3H",
    "serialNumber": "1234567890",
    "phase": "Three Phase",
    "confidence": "high"
  },
  "electrical": {
    "powerRating": "75 kVA",
    "primaryVoltage": "480V",
    "secondaryVoltage": "208Y/120V",
    "impedance": "3.5%",
    "insulationRating": "150°C",
    "temperatureRise": "80°C",
    "confidence": "high"
  },
  "mounting": {
    "type": "Floor",
    "confidence": "low"
  },
  "physicalDimensions": {
    "width": "Not Available - requires field measurement",
    "depth": "Not Available - requires field measurement",
    "height": "Not Available - requires field measurement",
    "weight": "850 lbs",
    "note": "Physical dimensions typically require field measurement and are not always on nameplates"
  },
  "wiringDetails": {
    "note": "Wiring details require field observation and cannot be determined from nameplate photo",
    "primaries": "Not Available - requires field observation",
    "secondaries": "Not Available - requires field observation",
    "wireMaterial": "Not Available - requires field observation",
    "wireSize": "Not Available - requires field observation",
    "conduitSize": "Not Available - requires field observation"
  },
  "confidenceScores": {
    "manufacturer": 1.0,
    "model": 1.0,
    "powerRating": 0.95,
    "primaryVoltage": 0.95,
    "secondaryVoltage": 0.95,
    "overall": 0.95
  },
  "extractionQuality": {
    "nameplateReadability": "EXCELLENT",
    "glarePresent": false,
    "focusIssues": false,
    "partialOcclusion": false,
    "weatheringDamage": false
  },
  "missingFields": [],
  "recommendedFollowup": [],
  "warnings": [
    "Impedance and temperature ratings are small print - verify in field if needed"
  ],
  "overallConfidence": "high"
}

EXAMPLE OUTPUT FOR GENERAL ELECTRIC TRANSFORMER WITH LIMITED INFO:
{
  "systemType": {
    "category": "Electrical Transformer",
    "transformerType": "Dry Type",
    "confidence": "high"
  },
  "basicInfo": {
    "manufacturer": "General Electric",
    "model": "9T23B3873",
    "serialNumber": "Not legible",
    "phase": "Three Phase",
    "confidence": "high"
  },
  "electrical": {
    "powerRating": "45 kVA",
    "primaryVoltage": "480V",
    "secondaryVoltage": "120/240V",
    "impedance": "Not Available",
    "insulationRating": "Not Available",
    "temperatureRise": "Not Available",
    "confidence": "medium"
  },
  "mounting": {
    "type": "Not Available",
    "confidence": "low"
  },
  "physicalDimensions": {
    "width": "Not Available - requires field measurement",
    "depth": "Not Available - requires field measurement",
    "height": "Not Available - requires field measurement",
    "weight": "Not Available",
    "note": "Physical dimensions typically require field measurement and are not always on nameplates"
  },
  "wiringDetails": {
    "note": "Wiring details require field observation and cannot be determined from nameplate photo",
    "primaries": "Not Available - requires field observation",
    "secondaries": "Not Available - requires field observation",
    "wireMaterial": "Not Available - requires field observation",
    "wireSize": "Not Available - requires field observation",
    "conduitSize": "Not Available - requires field observation"
  },
  "confidenceScores": {
    "manufacturer": 0.95,
    "model": 0.9,
    "powerRating": 0.9,
    "primaryVoltage": 0.85,
    "secondaryVoltage": 0.85,
    "overall": 0.75
  },
  "extractionQuality": {
    "nameplateReadability": "GOOD",
    "glarePresent": false,
    "focusIssues": false,
    "partialOcclusion": false,
    "weatheringDamage": true
  },
  "missingFields": [
    "serialNumber - not legible due to wear",
    "impedance - not visible",
    "insulationRating - not visible",
    "temperatureRise - not visible"
  ],
  "recommendedFollowup": [
    "Field verify detailed electrical ratings if needed for design",
    "Check for additional nameplate on other side of transformer"
  ],
  "warnings": [
    "Serial number not legible due to wear",
    "Detailed electrical ratings not visible on nameplate - verify in field"
  ],
  "overallConfidence": "medium"
}

Extract all visible information from the transformer nameplate. Be realistic about what can be seen in a photo. Focus on kVA, voltages, and phase - these are the critical specs. RETURN ONLY JSON, NO OTHER TEXT.`;

    // EQUIPMENT CLASSIFICATION PROMPT - Identify equipment type from image
    const equipmentClassificationPrompt = `You are an expert electrical engineer. Analyze this image and identify the type of electrical equipment shown.

CRITICAL: Your response must be ONLY valid JSON with no additional text before or after. Do not include explanations, markdown code blocks, or any other text. Start your response with { and end with }.

EQUIPMENT TYPES TO IDENTIFY:
1. **TRANSFORMER** - Look for: kVA rating, primary/secondary voltage, large metal cabinet with high voltage warning labels
2. **SERVICE_DISCONNECT** - Look for: Main breaker switch, service entrance label, amperage rating, typically near meter
3. **METER_ENCLOSURE** - Look for: Electric meter, meter socket, utility company seal, usually glass/plastic face showing dials or digital display
4. **PANEL_NAMEPLATE** - Look for: Panel manufacturer nameplate showing bus rating, voltage, model number (close-up of label)
5. **PANEL_INTERIOR** - Look for: Circuit breakers visible, circuit directory/schedule, breakers in rows
6. **UNKNOWN** - Cannot clearly identify equipment type

IMAGE QUALITY ASSESSMENT:
- **CLEAR**: Nameplate/labels fully legible, good lighting, minimal glare
- **PARTIAL**: Some labels legible but glare/blur/occlusion affects some areas
- **POOR**: Significant blur, heavy glare, or distance makes reading difficult
- **OCCLUDED**: Critical parts covered/blocked/cut off from frame

EXTRACTION FEASIBILITY:
- **FULL**: All critical data fields can be extracted with high confidence
- **PARTIAL**: Some critical fields extractable, others illegible
- **NONE**: Image quality too poor for reliable data extraction

RETURN THIS EXACT JSON STRUCTURE (NO OTHER TEXT):
{
  "equipmentType": "TRANSFORMER" | "SERVICE_DISCONNECT" | "METER_ENCLOSURE" | "PANEL_NAMEPLATE" | "PANEL_INTERIOR" | "UNKNOWN",
  "imageQuality": "CLEAR" | "PARTIAL" | "POOR" | "OCCLUDED",
  "confidence": "high" | "medium" | "low",
  "visibleDetails": [
    "List specific elements that led to this classification",
    "Examples: 'kVA rating visible', 'meter dials visible', 'circuit breakers visible', 'nameplate text legible'"
  ],
  "extractionFeasibility": "FULL" | "PARTIAL" | "NONE",
  "issues": [
    "List any issues affecting data extraction",
    "Examples: 'heavy glare on nameplate', 'image too far', 'text blurred', 'partial occlusion'"
  ]
}

CLASSIFICATION EXAMPLES:

TRANSFORMER:
- Visible: "75 kVA", "480V Primary", "208Y/120V Secondary", "DANGER HIGH VOLTAGE"
- Equipment type: TRANSFORMER

SERVICE DISCONNECT:
- Visible: "400A MAIN", "Service Entrance", disconnect switch handle, fuse holders
- Equipment type: SERVICE_DISCONNECT

METER ENCLOSURE:
- Visible: Meter face with dials/digital display, "kWh", utility company logo, meter socket
- Equipment type: METER_ENCLOSURE

PANEL NAMEPLATE (close-up):
- Visible: "Square D", "Model NF412L1C", "225A BUS", "120/208V 3Ø 4W"
- Equipment type: PANEL_NAMEPLATE

PANEL INTERIOR:
- Visible: Rows of circuit breakers, circuit directory, breaker labels, panel interior
- Equipment type: PANEL_INTERIOR

Analyze the image and classify the equipment. Focus on identifying key visual markers. RETURN ONLY JSON, NO OTHER TEXT.`;

    // SERVICE DISCONNECT ANALYSIS PROMPT
    const serviceDisconnectPrompt = `You are an expert electrical engineer analyzing a service disconnect or main service entrance equipment. Extract ALL visible information and return it in the exact JSON format below.

CRITICAL: Your response must be ONLY valid JSON with no additional text before or after. Do not include explanations, markdown code blocks, or any other text. Start your response with { and end with }.

CRITICAL INSTRUCTIONS:
1. Extract ONLY information visible on the nameplate/labels - be realistic about what can be read from a photo
2. For fields not visible: use "Not Available"
3. For fields that are worn/damaged/illegible: use "Not legible"
4. NEVER leave any field as null - always use either the actual value, "Not legible", or "Not Available"
5. Service disconnects typically show: amperage rating, voltage, fuse/breaker size, manufacturer

REALISTICALLY EXTRACTABLE FROM SERVICE DISCONNECT:
✓ Manufacturer name (if labeled)
✓ Amperage rating (e.g., 200A, 400A, 600A)
✓ Voltage (e.g., 120/240V, 208Y/120V, 480Y/277V)
✓ Phase configuration (single phase or three phase)
✓ Fuse size (if fused disconnect)
✓ Enclosure type (NEMA 1, 3R, etc.)
✗ Physical dimensions (need measurement)
✗ Internal wiring details (need to open enclosure)

CONFIDENCE SCORING:
Rate each field extraction from 0.0 to 1.0:
- 1.0 = Perfectly legible, no doubt
- 0.8-0.9 = Clearly visible, high confidence
- 0.6-0.7 = Partially visible, medium confidence
- 0.4-0.5 = Barely legible, low confidence
- 0.0-0.3 = Not legible or not available

RETURN THIS EXACT JSON STRUCTURE (NO OTHER TEXT):
{
  "systemType": {
    "category": "Service Disconnect",
    "disconnectType": "Fused Disconnect" | "Breaker Disconnect" | "Main Breaker" | "Not Available",
    "confidence": "high" | "medium" | "low"
  },
  "basicInfo": {
    "manufacturer": "string or 'Not legible' or 'Not Available'",
    "model": "string or 'Not legible' or 'Not Available'",
    "ampRating": "string with A (e.g., '200A', '400A') or 'Not legible' or 'Not Available'",
    "condition": "Good" | "Fair" | "Poor" | "Not Available",
    "confidence": "high" | "medium" | "low"
  },
  "electrical": {
    "voltage": "string (e.g., '120/240V', '208Y/120V') or 'Not legible' or 'Not Available'",
    "phase": "1-phase" | "3-phase" | "Not legible" | "Not Available",
    "wireConfig": "3-wire" | "4-wire" | "Not legible" | "Not Available",
    "fuseSize": "string with A (e.g., '200A') or 'Not Available' - only if fused disconnect",
    "enclosureType": "string (e.g., 'NEMA 1', 'NEMA 3R') or 'Not Available'",
    "confidence": "high" | "medium" | "low"
  },
  "mounting": {
    "type": "Surface" | "Recessed" | "Pole Mount" | "Pad Mount" | "Not Available",
    "confidence": "low" - usually cannot determine from photo alone
  },
  "confidenceScores": {
    "manufacturer": 0.0-1.0,
    "model": 0.0-1.0,
    "ampRating": 0.0-1.0,
    "voltage": 0.0-1.0,
    "overall": 0.0-1.0
  },
  "extractionQuality": {
    "nameplateReadability": "EXCELLENT" | "GOOD" | "FAIR" | "POOR",
    "glarePresent": true | false,
    "focusIssues": true | false,
    "partialOcclusion": true | false,
    "weatheringDamage": true | false
  },
  "missingFields": [
    "List fields that are Not Available or Not legible"
  ],
  "recommendedFollowup": [
    "Suggest actions if critical data is missing",
    "Examples: 'Retake photo without glare', 'Field verify amperage rating', 'Check for nameplate inside enclosure'"
  ],
  "warnings": [
    "List any illegible fields or critical issues"
  ],
  "overallConfidence": "high" | "medium" | "low"
}

Extract all visible information from the service disconnect. Be realistic about what can be seen in a photo. RETURN ONLY JSON, NO OTHER TEXT.`;

    // METER ENCLOSURE PROMPT
    const meterEnclosurePrompt = `You are an expert electrical engineer analyzing an electric meter enclosure. Extract ALL visible information and return it in the exact JSON format below.

CRITICAL: Your response must be ONLY valid JSON with no additional text before or after. Do not include explanations, markdown code blocks, or any other text. Start your response with { and end with }.

CRITICAL INSTRUCTIONS:
1. Extract ONLY information visible on the meter face/enclosure - be realistic about what can be read from a photo
2. For fields not visible: use "Not Available"
3. For fields that are worn/damaged/illegible: use "Not legible"
4. NEVER leave any field as null - always use either the actual value, "Not legible", or "Not Available"
5. Meters typically show: meter number, utility company, kWh reading, voltage (sometimes)

REALISTICALLY EXTRACTABLE FROM METER ENCLOSURE:
✓ Meter number (serial number on meter face)
✓ Utility company name/logo
✓ Meter type (analog dial, digital, smart meter)
✓ Current kWh reading (if visible)
✗ Voltage rating (often not labeled on meter face)
✗ Amperage capacity (usually not on meter, determined by meter socket/base)
✗ Internal wiring (not visible)

CONFIDENCE SCORING:
Rate each field extraction from 0.0 to 1.0:
- 1.0 = Perfectly legible, no doubt
- 0.8-0.9 = Clearly visible, high confidence
- 0.6-0.7 = Partially visible, medium confidence
- 0.4-0.5 = Barely legible, low confidence
- 0.0-0.3 = Not legible or not available

RETURN THIS EXACT JSON STRUCTURE (NO OTHER TEXT):
{
  "systemType": {
    "category": "Electric Meter",
    "meterType": "Analog Dial" | "Digital" | "Smart Meter" | "Not Available",
    "confidence": "high" | "medium" | "low"
  },
  "basicInfo": {
    "meterNumber": "string or 'Not legible' or 'Not Available'",
    "utilityCompany": "string or 'Not legible' or 'Not Available'",
    "currentReading": "string with kWh or 'Not Available' - only if visible",
    "condition": "Good" | "Fair" | "Poor" | "Not Available",
    "confidence": "high" | "medium" | "low"
  },
  "electrical": {
    "voltage": "string (e.g., '120/240V') or 'Not Available' - rarely labeled on meter face",
    "ampRating": "string with A or 'Not Available' - usually determined by meter base, not visible on meter",
    "phase": "1-phase" | "3-phase" | "Not Available",
    "confidence": "low" - voltage/amps typically not visible on meter face
  },
  "confidenceScores": {
    "meterNumber": 0.0-1.0,
    "utilityCompany": 0.0-1.0,
    "overall": 0.0-1.0
  },
  "extractionQuality": {
    "meterFaceReadability": "EXCELLENT" | "GOOD" | "FAIR" | "POOR",
    "glarePresent": true | false,
    "focusIssues": true | false,
    "partialOcclusion": true | false,
    "weatheringDamage": true | false
  },
  "missingFields": [
    "List fields that are Not Available or Not legible"
  ],
  "recommendedFollowup": [
    "Suggest actions if critical data is missing",
    "Examples: 'Photo of meter base needed for amperage rating', 'Retake without glare on meter face'"
  ],
  "warnings": [
    "List any illegible fields or critical issues",
    "Note: Voltage and amperage typically require inspecting meter socket/base, not visible on meter face"
  ],
  "overallConfidence": "high" | "medium" | "low"
}

IMPORTANT NOTE: Electric meters themselves usually only show meter number and utility company. Voltage/amperage specifications are typically on the meter socket/base or service entrance equipment, not the meter itself. Be realistic about this in your response.

Extract all visible information from the meter enclosure. RETURN ONLY JSON, NO OTHER TEXT.`;

    // Select the appropriate prompt based on equipment type
    let selectedPrompt;
    if (equipmentType === 'classification') {
      selectedPrompt = equipmentClassificationPrompt;
    } else if (equipmentType === 'service_disconnect') {
      selectedPrompt = serviceDisconnectPrompt;
    } else if (equipmentType === 'meter') {
      selectedPrompt = meterEnclosurePrompt;
    } else if (equipmentType === 'electrical') {
      selectedPrompt = electricalPanelPrompt;
    } else if (equipmentType === 'transformer') {
      selectedPrompt = transformerPrompt;
    } else {
      selectedPrompt = comprehensivePrompt;
    }

    console.log(`Calling Claude with ${equipmentType} analysis prompt...`);

    const content = [];

    if (imagesToAnalyze[0] === "test") {
      content.push({
        type: "text",
        text: "This is a test. Respond with 'Lambda is working!'",
      });
    } else {
      // Add the prompt first
      content.push({
        type: "text",
        text: selectedPrompt,
      });

      // Add ALL images to the content array
      // This allows Claude to see all images of the same panel for better analysis
      for (let i = 0; i < imagesToAnalyze.length; i++) {
        content.push({
          type: "image",
          source: {
            type: "base64",
            media_type: "image/jpeg",
            data: imagesToAnalyze[i],
          },
        });
      }

      // Add instruction to analyze all images
      if (imagesToAnalyze.length > 1) {
        content.push({
          type: "text",
          text: `⚠️ CRITICAL - MULTI-IMAGE ANALYSIS:

You have been provided with ${imagesToAnalyze.length} images. They serve DIFFERENT purposes:

IMAGE 1 (RTU NAMEPLATE):
- Use this for: manufacturer, model, serial number, electrical specs (voltage, phase, MCA, MOCP, RLA, LRA)
- Use this for: compressor data, fan motor data, cooling capacity/tonnage, refrigerant type
- Use this for: ALL standard nameplate data

IMAGE 2+ (FUSE LABEL or additional views):
- If this shows a FUSE LABEL (e.g., "FUSETRON 60 AMP", "30 AMP FUSE", etc.):
  * Extract ONLY the fuse/disconnect amperage rating from this image
  * Put this value in "electrical.fuseSize" or "electrical.disconnectSize"
  * Example: If you see "60 AMP" on the fuse label → fuseSize: "60 AMP"
- If this is another view of the same nameplate, use it to supplement/verify data from Image 1

DO NOT confuse data between images:
- Model number, serial number, RLA, LRA → Image 1 only
- Fuse/disconnect size → Image 2 only (if it's a fuse label)

Log which image you used for which data in your response.`,
        });
      }
    }

    const response = await bedrock
      .invokeModel({
        modelId: "anthropic.claude-3-haiku-20240307-v1:0",
        contentType: "application/json",
        accept: "application/json",
        body: JSON.stringify({
          anthropic_version: "bedrock-2023-05-31",
          max_tokens: 2000,
          temperature: 0.1,
          messages: [
            {
              role: "user",
              content: content,
            },
          ],
        }),
      })
      .promise();

    const result = JSON.parse(new TextDecoder().decode(response.body));
    console.log("✓ Bedrock responded");

    let parsedData;
    try {
      // Extract JSON from Claude's response
      const textContent = result.content?.[0]?.text || "{}";

      // Try to find JSON in the response (handle extra text before/after)
      let jsonStr = textContent;

      // Look for JSON object boundaries
      const jsonStart = textContent.indexOf("{");
      const jsonEnd = textContent.lastIndexOf("}");

      if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
        jsonStr = textContent.substring(jsonStart, jsonEnd + 1);
      }

      parsedData = JSON.parse(jsonStr);
    } catch (e) {
      console.log("JSON parse error, attempting to clean response:", e);

      // Try one more time with more aggressive cleaning
      try {
        const textContent = result.content?.[0]?.text || "{}";

        // Remove markdown code blocks if present
        let cleaned = textContent
          .replace(/```json\n?/g, "")
          .replace(/```\n?/g, "");

        // Find the first { and last }
        const firstBrace = cleaned.indexOf("{");
        const lastBrace = cleaned.lastIndexOf("}");

        if (firstBrace !== -1 && lastBrace !== -1) {
          cleaned = cleaned.substring(firstBrace, lastBrace + 1);
          parsedData = JSON.parse(cleaned);
        } else {
          throw new Error("No valid JSON found");
        }
      } catch (e2) {
        console.log("Still failed to parse, returning error:", e2);
        parsedData = {
          error: "Could not parse AI response",
          rawResponse: result.content?.[0]?.text,
          parseError: e2.message,
        };
      }
    }

    // Log extraction results for verification
    console.log("=== EXTRACTION RESULTS ===");
    if (parsedData.error) {
      console.log("❌ Extraction failed:", parsedData.error);
    } else {
      console.log("✓ Extraction successful");
      if (parsedData.basicInfo) {
        console.log(`  Manufacturer: ${parsedData.basicInfo.manufacturer || 'N/A'}`);
        console.log(`  Model: ${parsedData.basicInfo.model || 'N/A'} (${parsedData.basicInfo.model?.length || 0} chars)`);
        if (parsedData.basicInfo.model && parsedData.basicInfo.model.length > 18) {
          console.log(`    ⚠️ WARNING: Model length exceeds 18 characters - may have read too far`);
        }
        console.log(`  Serial: ${parsedData.basicInfo.serialNumber || 'N/A'}`);
        if (parsedData.basicInfo.serialNumber && (parsedData.basicInfo.serialNumber.includes('6') || parsedData.basicInfo.serialNumber.includes('8'))) {
          console.log(`    → Serial contains 6 or 8 - verify: 8 has TWO loops, 6 has ONE loop`);
        }
      }
      if (parsedData.electrical) {
        console.log(`  Unit Voltage: ${parsedData.electrical.voltage || 'N/A'}`);
        console.log(`  Unit Phase: ${parsedData.electrical.phase || 'N/A'} (from POWER SUPPLY row)`);
        console.log(`  MCA: ${parsedData.electrical.mca || parsedData.compressor1?.mca || 'N/A'}`);
        console.log(`  MOCP: ${parsedData.electrical.mocp || 'N/A'}`);
        console.log(`  Fuse Size: ${parsedData.electrical.fuseSize || parsedData.electrical.disconnectSize || 'N/A'}`);
        if (parsedData.electrical.fuseSize || parsedData.electrical.disconnectSize) {
          console.log(`    → Fuse data extracted from: ${imagesToAnalyze.length > 1 ? 'Image 2 (fuse label)' : 'Image 1 (nameplate)'}`);
        }
      }
      if (parsedData.compressor1) {
        console.log(`  Compressor RLA: ${parsedData.compressor1.rla || 'N/A'} (from COMP A row)`);
        console.log(`  Compressor LRA: ${parsedData.compressor1.lra || 'N/A'} (from COMP A row)`);
      }
      if (parsedData.outdoorFanMotor) {
        console.log(`  Outdoor Fan FLA: ${parsedData.outdoorFanMotor.fla || 'N/A'} (from FAN MTR OUTDOOR row)`);
        console.log(`  Outdoor Fan Phase: ${parsedData.outdoorFanMotor.phase || 'N/A'} (motor only, NOT unit phase)`);
      }
      if (parsedData.indoorFanMotor) {
        console.log(`  Indoor Fan FLA: ${parsedData.indoorFanMotor.fla || 'N/A'} (from FAN MTR INDOOR row)`);
        console.log(`  Indoor Fan Phase: ${parsedData.indoorFanMotor.phase || 'N/A'} (motor only, NOT unit phase)`);
      }
      if (parsedData.cooling) {
        console.log(`  Tonnage: ${parsedData.cooling.tonnage || 'N/A'}`);
      }
      console.log(`  Overall Confidence: ${parsedData.overallConfidence || 'N/A'}`);
    }

    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify({
        success: true,
        message: "Complete analysis finished",
        data: parsedData,
        timestamp: new Date().toISOString(),
      }),
    };
  } catch (error) {
    console.error("❌ Lambda error:", error);
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      }),
    };
  }
};
